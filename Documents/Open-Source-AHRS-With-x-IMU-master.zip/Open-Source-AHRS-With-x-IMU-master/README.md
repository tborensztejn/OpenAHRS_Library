Open-Source-AHRS-With-x-IMU
===========================

More information available on [website](http://www.x-io.co.uk/open-source-ahrs-with-x-imu/).
